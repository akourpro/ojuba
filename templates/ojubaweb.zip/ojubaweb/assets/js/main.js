/* ======================================================================
   Ojuba Web theme — assets/js/main.js
   نمط "شبكة الأمان" لعناصر .reveal مبني على أسلوب قالب goldenphase
   (querySelectorAll مباشر + كلاس in-view + مهلة أمان) بدل مصفوفة
   revealSelectors اليدوية المستخدمة بقوالب أخرى — أكثر أماناً لأي كلاس
   reveal جديد يُضاف مستقبلاً لأي Twig بهذا القالب دون تحديث هذا الملف.
   ====================================================================== */
document.addEventListener('DOMContentLoaded', function () {
  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- Persist current language across internal links ---------- */
  (function () {
    var curLang = document.documentElement.lang;
    if (curLang !== 'ar' && curLang !== 'en') return;
    var anchors = document.querySelectorAll('a[href]');
    Array.prototype.forEach.call(anchors, function (a) {
      var raw = a.getAttribute('href');
      if (!raw || raw.charAt(0) === '#' || raw.indexOf('mailto:') === 0 || raw.indexOf('tel:') === 0 || raw.indexOf('javascript:') === 0) return;
      var url;
      try {
        url = new URL(raw, document.baseURI);
      } catch (e) {
        return;
      }
      if (url.origin !== location.origin || url.searchParams.has('lang')) return;
      url.searchParams.set('lang', curLang);
      a.setAttribute('href', url.toString());
    });
  })();

  /* ---------- Mobile nav toggle ---------- */
  var navToggle = document.getElementById('navToggle');
  var mobileMenu = document.getElementById('mobileMenu');
  if (navToggle && mobileMenu) {
    navToggle.addEventListener('click', function () {
      mobileMenu.classList.toggle('open');
    });
    mobileMenu.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () { mobileMenu.classList.remove('open'); });
    });
  }

  /* ---------- Dark / light mode toggle ---------- */
  var root = document.documentElement;
  var themeToggle = document.getElementById('themeToggle');
  if (themeToggle) {
    themeToggle.addEventListener('click', function () {
      var current = root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
      var next = current === 'dark' ? 'light' : 'dark';
      root.setAttribute('data-theme', next);
      try { localStorage.setItem('ojubaweb-theme', next); } catch (e) {}
    });
  }

  /* ---------- Hide sticky mobile CTA bar once the final download banner is on screen ---------- */
  var ctaBar = document.querySelector('.mobile-cta-bar');
  var downloadSection = document.getElementById('download');
  if (ctaBar && downloadSection && 'IntersectionObserver' in window) {
    var ctaObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        ctaBar.classList.toggle('hide', entry.isIntersecting);
      });
    }, { threshold: 0.3 });
    ctaObserver.observe(downloadSection);
  }

  /* ---------- Blog listing: client-side title search ---------- */
  var blogGrid = document.getElementById('blogGrid');
  var searchInput = document.getElementById('blogSearch');
  var noResults = document.getElementById('noResults');
  if (blogGrid && searchInput) {
    var cards = blogGrid.querySelectorAll('.blog-card');
    var applySearch = function () {
      var query = (searchInput.value || '').trim().toLowerCase();
      var visibleCount = 0;
      cards.forEach(function (card) {
        var text = (card.getAttribute('data-title') || '').toLowerCase();
        var visible = query === '' || text.indexOf(query) !== -1;
        card.style.display = visible ? '' : 'none';
        if (visible) { visibleCount++; }
      });
      if (noResults) { noResults.style.display = visibleCount === 0 ? 'block' : 'none'; }
    };
    searchInput.addEventListener('input', applySearch);
  }

  /* ---------- FAQ accordion: close siblings when one <details> opens ---------- */
  document.querySelectorAll('.faq').forEach(function (group) {
    var items = group.querySelectorAll('details');
    items.forEach(function (item) {
      item.addEventListener('toggle', function () {
        if (!item.open) return;
        items.forEach(function (other) {
          if (other !== item) other.open = false;
        });
      });
    });
  });

  /* ---------- Copy article link (blog detail / page) ---------- */
  var copyBtn = document.getElementById('copyLinkBtn');
  if (copyBtn) {
    copyBtn.addEventListener('click', function () {
      var url = window.location.href;
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(url).then(function () {
          copyBtn.style.borderColor = 'var(--success)';
          setTimeout(function () { copyBtn.style.borderColor = ''; }, 1200);
        });
      }
    });
  }

  if (reduceMotion) { return; }

  /* ---------- Scroll reveal (direct querySelectorAll — no manual selector array) ---------- */
  var revealTargets = document.querySelectorAll(
    '.section-head, .pillar, .feature, .flow-step, .compare, .hero-shot, ' +
    '.team-card, .testimonial-card, .clients-strip, .pricing-card, .faq details, ' +
    '.contact-form, .info-card, .social-box, .blog-card, .newsletter, .cta'
  );

  function animateCounters() {
    document.querySelectorAll('.mock-stat .v[data-target]').forEach(function (el) {
      var target = parseInt(el.getAttribute('data-target'), 10) || 0;
      var suffix = el.getAttribute('data-suffix') || '';
      var duration = 900;
      var startTime = null;
      function step(ts) {
        if (!startTime) { startTime = ts; }
        var progress = Math.min((ts - startTime) / duration, 1);
        el.textContent = Math.round(target * progress) + suffix;
        if (progress < 1) { requestAnimationFrame(step); }
      }
      requestAnimationFrame(step);
    });
  }

  if (revealTargets.length && 'IntersectionObserver' in window) {
    revealTargets.forEach(function (el, i) {
      el.classList.add('reveal');
      el.style.transitionDelay = (i % 6) * 60 + 'ms';
    });
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    revealTargets.forEach(function (el) { io.observe(el); });
  } else if (revealTargets.length) {
    revealTargets.forEach(function (el) { el.classList.add('reveal', 'in-view'); });
  }

  /* شبكة أمان: أي عنصر .reveal يبقى بدون in-view بعد 3.5 ثانية يُظهَر تلقائياً */
  setTimeout(function () {
    document.querySelectorAll('.reveal:not(.in-view)').forEach(function (el) {
      el.classList.add('in-view');
    });
  }, 3500);

  /* Animated counters once the hero preview scrolls into view */
  var heroShot = document.querySelector('.hero-shot');
  if (heroShot && 'IntersectionObserver' in window) {
    var counted = false;
    var countIo = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting && !counted) {
          counted = true;
          animateCounters();
          countIo.unobserve(entry.target);
        }
      });
    }, { threshold: 0.4 });
    countIo.observe(heroShot);
  } else if (heroShot) {
    animateCounters();
  }
});
